from django.shortcuts import render, HttpResponse, redirect
from django.http import JsonResponse

def root(request):
    return HttpResponse("this is the equivalent of @app.route('/')")

def index(request):
    return HttpResponse("placeholder to later display a list of all blogs")

def views(request):
    return HttpResponse("placeholder to display a new form to create a new blog")

def new(request):
    return HttpResponse("placeholder to display a new form to create a new blog")

def create(request):
    return redirect("/")

def show(request,number):
    return HttpResponse(f"place holder to edit blog {number} ",number)

def edit(request,number):
    return HttpResponse(f"place holder to edit blog {number} ",number)

def destroy(request,number):
    return redirect('/blogs')

def myjson(request):
    return JsonResponse({"title": "JSON Object", "content": "my JSON"})